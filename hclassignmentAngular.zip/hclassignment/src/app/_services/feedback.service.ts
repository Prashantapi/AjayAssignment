import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { ServiceFeedBackModel } from '../_models/feedback.model';

const getEmployeeUrl = `${environment.apiUrl}/api/FeedBack/GetEmployee`;
const SaveServiceFeedBackUrl = `${environment.apiUrl}/api/FeedBack/Employee/ServiceFeedBack/Save`;

@Injectable({
  providedIn: 'root'
})
export class FeedbackService {
  
  constructor(private http: HttpClient) { }

  getEmployee(empID:Number) {
    return this.http.get<any>(getEmployeeUrl + '?empID=' + empID);
  }

  SaveServiceFeedBack(serviceFeedbackModelList:[]) {
    return this.http.post<any>(SaveServiceFeedBackUrl, serviceFeedbackModelList);
  }
}
