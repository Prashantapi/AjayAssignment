export class EmployeeModel {
    public Name: string = "";
    public EmpID: number = 0;
}
export class ServiceFeedBackModel {
    public EmpID: number = 0;
    public ServiceTypeID: number = 0;
    public FeedBackTypeID: number = 0;
}
