import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ServiceFeedBackModel, EmployeeModel } from 'src/app/_models/feedback.model';
import { FeedbackService } from 'src/app/_services/feedback.service';

@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  employeeForm: FormGroup;
  serviceFeedbackModelList: any = [];
  result: any;
  elements: any;
  constructor(private feedbackService: FeedbackService, private formBuilder: FormBuilder) {
    this.employeeForm = new FormGroup({
      overall: new FormControl(),
      food: new FormControl(),
      lab: new FormControl()
    });
  }
  ngOnInit(): void {
    let empID = 1;// here hardcode employeeid passed for feedback of an existing employee
    this.feedbackService.getEmployee(empID).subscribe((result: any) => {
      this.result = result;
    });
  }
  onFormSubmit() {
    //validation need to do and update for the sane employee if that employee submit form again and again
    //here created two more table(tblServiceType and tblFeedBackType) for dynamic form, 
    //and in future if more service added and more feedback added then easy for data management
    let data = this.employeeForm.value;
    this.serviceFeedbackModelList = [
      {
        EmpID: 1,
        ServiceTypeID: 1,
        FeedBackTypeID: parseInt(data.overall)
      },
      {
        EmpID: 1,
        ServiceTypeID: 2,
        FeedBackTypeID: parseInt(data.food)
      },
      {
        EmpID: 1,
        ServiceTypeID: 3,
        FeedBackTypeID: parseInt(data.lab)
      }
    ];
    this.feedbackService.SaveServiceFeedBack(this.serviceFeedbackModelList).subscribe((result: any) => {
      //here need to do if macteches from response statusCode == 200 then response message show      
    });
    alert("Employee Feedback saved successfully.");
  }
}