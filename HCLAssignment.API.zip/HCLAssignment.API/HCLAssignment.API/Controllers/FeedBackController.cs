﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HCLAssignment.DataContract;
using HCLAssignment.ServiceContract;
using Microsoft.AspNetCore.Mvc;


namespace HCLAssignment.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FeedBackController : ControllerBase
    {
        protected readonly IFeedBackService _feedBackService;
        public FeedBackController(IFeedBackService feedBackService) 
        {
            _feedBackService = feedBackService;
        }       

        [HttpGet]
        [Route("GetEmployee")]
        public async Task<IActionResult> GetEmployee(int empID)
        {
            //here generic ResponseStatus need to make
            var result = await _feedBackService.GetEmployee(empID);
            if(result != null)
                return Ok(result); // here after using generic ResponseStatus class, employee detail need to send by generic type Member of class
            else
                return Ok("No record found"); //here need HttpStatusCode.NoContent for exact error code
        }       
       
        [HttpPost]
        [Route("Employee/ServiceFeedBack/Save")]
        public async Task<IActionResult> SaveServiceFeedBack(List<ServiceFeedBackModel> serviceFeedBackModel)
        {
            var result = await _feedBackService.SaveServiceFeedBack(serviceFeedBackModel);
            if (result == 1)
                return Ok("Employee Feedback saved successfully.");//here static class need to make for messages;
            else
                return Ok("Error while processing request."); //here static class need to make for messages and also 501 or bad request error code return 
        }        
    }
}
