﻿using HCLAssignment.DataContract;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HCLAssignment.ServiceContract
{
    public interface IFeedBackService
    {
        Task<EmployeeModel> GetEmployee(int empID); 
        Task<int> SaveServiceFeedBack(List<ServiceFeedBackModel> serviceFeedBackModel);
    }
}
