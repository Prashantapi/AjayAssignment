﻿using System;
using System.Collections.Generic;

namespace HCLAssignment.DataContract
{    
    public class ServiceFeedBackModel
    {
        public int EmpID { get; set; }
        public int ServiceTypeID { get; set; }
        public int FeedBackTypeID { get; set; }
    }
    public class EmployeeModel
    {
        public int EmpID { get; set; }
        public string Name { get; set; }
    }
}
