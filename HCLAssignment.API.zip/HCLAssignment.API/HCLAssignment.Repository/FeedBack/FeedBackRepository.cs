﻿using HCLAssignment.RepositoryContract;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;
using Dapper;
using System.Data;
using HCLAssignment.DataContract;

namespace HCLAssignment.Repository
{
    public class FeedBackRepository : BaseRepository, IFeedBackRepository
    {
        public FeedBackRepository(IConfiguration configuration) : base(configuration)
        {
        }

        public async Task<EmployeeModel> GetEmployee(int empID)
        {
            var query = "sp_getemployee";
            DynamicParameters parameter = new DynamicParameters();
            try
            {
                parameter.Add("@EmpID", empID, DbType.Int32, ParameterDirection.Input);
                return await GetFirstOrDefaultAsync<EmployeeModel>(query, parameter, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                return null;
            }           
        }        

        public async Task<int> SaveServiceFeedBack(ServiceFeedBackModel serviceFeedBackModel)
        {
            var query = "sp_saveservicefeedback";
            DynamicParameters parameter = new DynamicParameters();
            try
            {
                parameter.Add("@EmpID", serviceFeedBackModel.EmpID, DbType.Int32, ParameterDirection.Input);
                parameter.Add("@ServiceTypeID", serviceFeedBackModel.ServiceTypeID, DbType.Int32, ParameterDirection.Input);
                parameter.Add("@FeedBackTypeID", serviceFeedBackModel.FeedBackTypeID, DbType.Int32, ParameterDirection.Input);
                return await GetFirstOrDefaultAsync<int>(query, parameter, commandType: CommandType.StoredProcedure);
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
    }    
}
