﻿using Dapper;
using HCLAssignment.RepositoryContract;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Threading.Tasks;

namespace HCLAssignment.Repository
{   
    public class BaseRepository : IBaseRepository
    {
        public IConfiguration Configuration;
        private string _connectionString = string.Empty;
        public BaseRepository(IConfiguration configuration)
        {
            Configuration = configuration;
            _connectionString = configuration["ConnectionString:EmployeeConnectionString"];                               
        }
        public async Task<T> GetFirstOrDefaultAsync<T>(string sql, object parameters = null, int? commandTimeout = null, CommandType? commandType = null)
        {
            T result = default(T);
            try
            {
                using (IDbConnection conn = GetConnection("hclassignment"))
                {
                    result = await conn.QueryFirstOrDefaultAsync<T>(sql, parameters, null, commandTimeout, commandType);
                }
            }
            catch (Exception ex) { }


            return result;
        }
        private IDbConnection GetConnection(string databaseName)
        {
            string connectionString = _connectionString;

            if (databaseName == "hclassignment")
            {
                connectionString = _connectionString;
            }

            return new SqlConnection(connectionString);
        }
    }
}
