﻿using HCLAssignment.DataContract;
using HCLAssignment.RepositoryContract;
using HCLAssignment.ServiceContract;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace HCLAssignment.Service
{
    public class FeedBackService: IFeedBackService
    {
        private readonly IFeedBackRepository _feedBackRepository;
        public FeedBackService(IFeedBackRepository feedBackRepository)
        {
            _feedBackRepository = feedBackRepository;
        }

        public async Task<EmployeeModel> GetEmployee(int empID)
        {
            return await _feedBackRepository.GetEmployee(empID);            
        }

        public async Task<int> SaveServiceFeedBack(List<ServiceFeedBackModel> serviceFeedBackModel)
        {
            int result = 0;
            foreach(var item in serviceFeedBackModel)  
            {
                result= await _feedBackRepository.SaveServiceFeedBack(item);  //here need datatable or by xml for all entry at a time
            }
            return result;
        }
    }
}
