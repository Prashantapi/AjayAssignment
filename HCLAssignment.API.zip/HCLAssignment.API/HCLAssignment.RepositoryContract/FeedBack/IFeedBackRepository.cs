﻿using HCLAssignment.DataContract;
using System;
using System.Threading.Tasks;

namespace HCLAssignment.RepositoryContract
{
    public interface IFeedBackRepository
    {
        Task<EmployeeModel> GetEmployee(int empID);
        Task<int> SaveServiceFeedBack(ServiceFeedBackModel serviceFeedBackModel);
    }
}
