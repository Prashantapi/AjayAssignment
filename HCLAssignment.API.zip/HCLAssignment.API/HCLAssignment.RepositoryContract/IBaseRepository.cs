﻿using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace HCLAssignment.RepositoryContract
{
    public interface IBaseRepository
    {        
    }
}
